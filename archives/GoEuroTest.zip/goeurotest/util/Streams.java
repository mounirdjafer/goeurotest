package goeurotest.util;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;

/**
 * @Class Streams, utility functions to manage streams
 * @author Mr. Mounir DJAFER
 * @mailto: mounir.djafer@aol.com
 *
 */
public class Streams {

	
	//open file and write a stream
	/**
	 * 
	 * @param directoryPath
	 * @param fileName
	 * @param data
	 * @param append, true if the stream is written at the end of the file
	 * @throws IOException 
	 */
	public static void bytesToFile(String directoryPath, String fileName, byte[] data, boolean append) {
		File file = Files_io.createFile_using_URI(directoryPath, fileName);
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(file, append);
			for(int i=0; i < data.length; i++) {
				fos.write(data[i]);
			}			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			try {
				fos.flush();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * @name fileToString
	 * Convert a file to a String
	 * line of the files are separated by "\n"
	 * directoryPath
	 * @param fileName
	 * @return String representation of the file in UTF-8 
	 * line separator is "\n"
	 */
	public static String fileToString(String directoryPath, String ressourceName){
		File file = Files_io.createFileObject_using_URI(directoryPath,ressourceName);
		FileInputStream fis = null;
		BufferedReader br = null;
		InputStreamReader isr = null;
		StringBuffer stringBuffer = null;
		try {
			String line = null;
			stringBuffer = new StringBuffer();
			fis = new FileInputStream(file);
			isr = new InputStreamReader(fis, "UTF-8");
			br = new BufferedReader(isr);
			
			while ((line = br.readLine()) != null){
				stringBuffer.append(String.valueOf(line));
				stringBuffer.append("\n");
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			try {
				fis.close();isr.close();br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}			
		}
		return stringBuffer.toString();
	}
	public static String streamToString(InputStream inputStream, String charset) {
		String datas = null;
		InputStreamReader inputStreamReader= null;
		BufferedReader bufferedReader = null;	
		StringBuffer stringBuffer = null;
		ByteBuffer bb = null;
		String data = null;
		try {
			inputStreamReader = new InputStreamReader(inputStream, charset);
			bufferedReader = new BufferedReader(inputStreamReader);
			stringBuffer = new StringBuffer();
			//bb = ByteBuffer.allocate(10000);
			while((data = bufferedReader.readLine()) != null) {	
				stringBuffer.append(data);
				//bb.putInt(data);
			}
			datas = stringBuffer.toString();	
			//datas = new String(bb.array(), Charset.forName(charset));
			inputStreamReader.close();
			bufferedReader.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return datas;
	}
}
