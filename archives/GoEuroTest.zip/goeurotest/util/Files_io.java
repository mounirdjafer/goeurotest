package goeurotest.util;
import java.io.File;
import java.io.IOException;
import java.net.URI;

/**
 * @Class File_io, file utility class
 * @author Mr. Mounir DJAFER
 * @mailto: mounir.djafer@aol.com
 *
 */

public class Files_io {
	public static File createFile_using_URI(String directoryPath, String fileName_with_extension) {
		URI uri = URIs.createURI(directoryPath, fileName_with_extension);
		File file = new File(uri);
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return file;
	}
	
	public static File createFileObject_using_URI(String directoryPath, String fileName_with_extension) {
		URI uri = URIs.createURI(directoryPath, fileName_with_extension);			
		File file = new File(uri);
		return file;
	}
	public static File createFile_using_File_Path(String directoryPath, String fileName_with_extension) {
		File file = new File(directoryPath+System.getProperty("file.separator")+fileName_with_extension);
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return file;
	}
}
