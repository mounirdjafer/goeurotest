package goeurotest.util;
import java.net.URI;
import java.net.URISyntaxException;

import goeurotest.core.Logger;

/**
 * @Class URis, utility class
 * @author Mr. Mounir DJAFER
 * @mailto: mounir.djafer@aol.com
 *
 */
public class URIs {
	public static URI createURI(String directoryPath, String ressourceName ) {
		try {		
			URI uri = new URI(directoryPath+ressourceName);//new URI (directoryPath+ressourceName);			
			return uri;
		} catch (URISyntaxException e) {
			e.printStackTrace();
			return null;
		}		
	}
/*public static String convertPathToURIPath(String path) {
	boolean windows = System.getProperty("").matches("");
	if(windows) { 
		
	} else if(unix) {
	
	} else { //save at root dir
		
	}	
	return null;	
	}*/
}