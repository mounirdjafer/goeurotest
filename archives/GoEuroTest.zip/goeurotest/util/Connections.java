package goeurotest.util;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.URL;
import java.net.URLConnection;

/**
 * @Class Connections, manage connections
 * @author Mr. Mounir DJAFER
 * @mailto: mounir.djafer@aol.com
 *
 */



public class Connections {
	
	public static class ConnectionParams {
		public boolean connected;
		public long timeout;
		
	}
	/**
	 * 
	 * @param url_string
	 * @param proxyType
	 * @param socketAddress
	 * @param proxy_enabled
	 * @return an url connection
	 */
	public static URLConnection makeURLConnection (String url_string,
								Proxy.Type proxyType,
								SocketAddress socketAddress, 
								boolean proxy_enabled) {
		
		URL url;
		URLConnection urlConnection = null;
		try {
			url = new URL(url_string);
			if(proxy_enabled) {
				urlConnection = url.openConnection(new Proxy(proxyType, socketAddress) );
			} else {
				urlConnection = url.openConnection();
				System.out.println(urlConnection);
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return urlConnection;
	}
	public static void connect_with_Http(URLConnection urlConnection, String method) {
		
		try {
			HttpURLConnection httpURLConnection = (HttpURLConnection)urlConnection;
			httpURLConnection.setRequestMethod(method);
			httpURLConnection.connect();
			System.out.println("response code:"+httpURLConnection.getResponseCode());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
	}
}
