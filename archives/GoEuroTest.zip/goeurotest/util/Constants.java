package goeurotest.util;

/**
 * @Class Constants, store the program constants
 * @author Mr. Mounir DJAFER
 * @mailto: mounir.djafer@aol.com
 *
 */

public class Constants {
	
	public static final String json_directoryPath ="file:/prog/eclipse_j2EE_mars/GoEuroTest/";
	public static final String json_ressourceName ="json_doc.txt";
	public static final String csv_directoryPath ="file:/";//"file:/prog/eclipse_j2EE_mars/GoEuroTest/";
	public static final String csv_filename_extension = ".csv";
	public static final String log_directoryPath ="file:/goeuro_log/";
	public static final String log_file_name=""; 
	public static final String log_file_extension=""; 
	public static final String json_url="http://api.goeuro.com/api/v2/position/suggest/en/";
	public static final String request_method = "GET";
	public static final int data_array_max_size = 0;
	public static final int key_buffer_size = 100;
	public static final int value_buffer_size = 100;
	public static final String[] csv_headers = {"_id","name","type","latitude","longitude"};
	public static final String charset_name = "UTF-8";
}
