package goeurotest.main;

import java.net.URLConnection;
import java.util.ArrayList;
import goeurotest.core.CommandLineManager;
import goeurotest.core.Downloader;
import goeurotest.core.Formater;
import goeurotest.core.Logger;
import goeurotest.core.Parser;
import goeurotest.core.Storer;
import goeurotest.util.Connections;
import goeurotest.util.Constants;

/**
 * @Class Main, launch the program functions
 * @author Mr. Mounir DJAFER
 * @mailto: mounir.djafer@aol.com
 *
 */
public class Main {

	public static void main(String[] args) {
		//0- make url from the command line
		String CITY_NAME = args[0];
		String user_working_directory = System.getProperty("user.dir");//to save csv in working dir
		String json_url = CommandLineManager.add_CITY_NAME_To_JSON_FileURL(args);
		//1- Get remote JSON Datas as a String		
		URLConnection urlConnection = Connections.makeURLConnection(json_url, null, null, false); 
		Connections.connect_with_Http(urlConnection,Constants.request_method);
		String json	 = Downloader.download_string(urlConnection,Constants.charset_name);
		Logger.log(json);
		//2- extract keys values from JSON String,  
		ArrayList<String> json_keys_values = Parser.parse(json);
		//3- filter to get only values of the CSV header  
		ArrayList<String[]> csv_lines_list = Formater.JSON_Data_To_csv_format(Constants.csv_headers, json_keys_values);		
		//4- Store headers values in a csv file
		Storer.store_in_csv(csv_lines_list, user_working_directory, CITY_NAME, false/*don't append*/, true/*write csv headers*/);
	}
}
