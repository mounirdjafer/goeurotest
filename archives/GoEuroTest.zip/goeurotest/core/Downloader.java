package goeurotest.core;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URLConnection;
import goeurotest.util.Streams;
/**
 * @Class Downloader, download according url
 * @author Mr. Mounir DJAFER
 * @mailto: mounir.djafer@aol.com
 *
 */
public class Downloader {
	/**
	 * 
	 * @param urlConnection
	 * @param charset
	 * @return
	 */
	public static String download_string(URLConnection urlConnection,String charset) {
		String datas = null;
		try {
			InputStream inputStream = urlConnection.getInputStream();
			if(inputStream == null) {System.out.println("inputstream null");}
			else {
				 Logger.log("inputstream bytes available:"+inputStream.available());
			}
			
			datas = Streams.streamToString(inputStream, charset);	
			inputStream.close();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return datas;
	}
}
