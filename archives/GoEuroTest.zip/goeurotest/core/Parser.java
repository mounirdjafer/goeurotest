package goeurotest.core;
import java.util.ArrayList;

/**
 * @Class Parser, json parser
 * @author Mr. Mounir DJAFER
 * @mailto: mounir.djafer@aol.com
 *
 */

public class Parser {
 
	
 	//TODO check if well formed JSON
 	public static boolean check_JSON_well_formed(String stringToParse) {
 		return true;
 	}
 	/**
 	  * @param stringToParse
 	  */
	public static ArrayList<String>  parse(String stringToParse) 
	{
	
		char[] datas = Formater.remove_space_newline_chars_From_csv(stringToParse.toCharArray());
		int datas_length = datas.length;
		
		StringBuilder data = new StringBuilder();
		ArrayList<String> datas_key_values = new ArrayList<String>();
		boolean begin_quoted_string = false;
		int quote_counter = 0; 
	
		for (int datas_index = 0; datas_index < datas_length; datas_index++) {
			if (datas[datas_index] == '[' | 
				datas[datas_index] ==	'{' | //if char is a reserved JSON char separator
				datas[datas_index] ==	':' | //encoutered inside object or key,value pairs
				datas[datas_index] ==	'}' | //don't fill the buffer,   
				((datas[datas_index] ==	',') && (!begin_quoted_string) )| // but maybe to add buffer data to the data_key_values list
				datas[datas_index] ==	'"' |  // above condition avoid remove ',' inside a quoted string value   
				datas[datas_index] == ']' 
				) {
				
				//this code manage the case of a quoted string
				if (datas[datas_index] ==	'"' ) { 
					if(quote_counter%2 == 0) { //begining of a quoted string, quote counter is par 
						begin_quoted_string = true; 
					} else {                    //end of a quoted string, quote counter is unpar
						begin_quoted_string = false;
					}
					quote_counter++; 
				}
				if(data.length() == 0) { //if the buffer is empty
									
				} else { //the buffer is not empty,  
					if (!begin_quoted_string) { //if quoted string wait until end of quoted string
						String temp = data.toString();
						if (temp.length()!=0)datas_key_values.add(temp); //add data
						data.delete(0,data.length());//flush the buffer 
					}						
				}
			} else {
				//if(datas[datas_index] != 0) {
				data.append(datas[datas_index]);
				//}
			}
		}
		return datas_key_values;
		
	}
	
		
		private static ArrayList<String>  cleanDatas(ArrayList<String> datas) {
		for(int i=0; i < datas.size(); i++) {
			
			
			if(datas.get(i).length() == 0) datas.remove(i);
			String temp = datas.get(i).trim();
			datas.set(i, temp);
		}
		return datas;
	}
}