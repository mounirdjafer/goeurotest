package goeurotest.core;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import goeurotest.util.Constants;
import goeurotest.util.Files_io;

/**
 * @Class Logger, 
 * @author Mr. Mounir DJAFER
 * @mailto: mounir.djafer@aol.com
 *
 */

public class Logger {
	public static void log(String message) {
		System.out.println(message);
	}
	
	public static void log_exception(Exception exception, boolean log_in_file, boolean log_in_console)  {
		if(log_in_console) {
			PrintWriter console_log_writer = new PrintWriter(System.out);
			exception.printStackTrace(console_log_writer);
		}
		if (log_in_file) {
			File file = Files_io.createFile_using_URI(Constants.log_directoryPath, Constants.log_file_name);
			PrintWriter file_log_writer = null;
			try {
				file_log_writer = new PrintWriter(file);				
				exception.printStackTrace(file_log_writer);
			} catch (FileNotFoundException fileNotFoundException) {	
				fileNotFoundException.printStackTrace();
						
			}
			file_log_writer.flush();
			file_log_writer.close();
		}
	}
	
	
	/*private static String makeLogFileName() {
		
	}*/
	
}
