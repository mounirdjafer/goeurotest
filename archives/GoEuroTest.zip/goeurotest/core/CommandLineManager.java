package goeurotest.core;

import goeurotest.util.Constants;

/**
 * @Class CommandLineManager, manage command line arguments
 * @author Mr. Mounir DJAFER
 * @mailto: mounir.djafer@aol.com
 *
 */

public class CommandLineManager {
	
	public static String add_CITY_NAME_To_JSON_FileURL(String[] commandLineArgs) {
		String CITY_NAME = commandLineArgs[0];
		if(CITY_NAME == null) Logger.log("please enter a city name.");
		return Constants.json_url+CITY_NAME;
	}	
}
