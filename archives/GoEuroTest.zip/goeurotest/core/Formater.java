package goeurotest.core;

import java.util.ArrayList;
/**
 * @Class Formater, format json datas to csv
 * @author Mr. Mounir DJAFER
 * @mailto: mounir.djafer@aol.com
 *
 */
public class Formater {
	/**
	 * @param headers, are ordered in the same order as in the JSON file.
	 * @param datas
	 * @return
	 */
	public static ArrayList<String[]> JSON_Data_To_csv_format(String[] csv_headers, ArrayList<String> json_datas ) {
		//csv headers are JSON keys, we must extract JSON keys values from data.
		//we assume that theirs values are simple strings not objects nor quoted string.
		//thus these values  follows immediately their keys in the datas list.
		//data: is a json key or value
		
		String[] line_of_csv_values = new String[csv_headers.length];
		int j=0; //index of the array containing values of one csv line. 
		ArrayList<String[]> list_of_csv_lines_values = new ArrayList<String[]>();//will contains all lines of the csv file
		String json_data_i = null;
		String csv_header_j = null;
		for (int i=0; i < json_datas.size(); i++) { //walk through json datas 
			json_data_i = json_datas.get(i).trim();
			csv_header_j = csv_headers[j];
			if((json_data_i).equals(csv_header_j)) { //if it is a json key like in the csv headers
				
				line_of_csv_values[j] = json_datas.get(i+1);  //get it's value and store it in the csv line record
				j++; //increment record and headers index to get next record at the next loop
				if(j == csv_headers.length) { 
					//one line completed reset index of csv record array
					j=0;
					//save the record into the record list
					list_of_csv_lines_values.add(line_of_csv_values);
					line_of_csv_values = new String[csv_headers.length];//reset line				
				}
			}
		}
		return list_of_csv_lines_values;
	}
	
	public static char[] remove_space_newline_chars_From_csv(char[] csv){
		boolean quotedString = false;
		StringBuilder sb = new StringBuilder();
		for (int i=0; i < csv.length;i++) {
			if(csv[i] == '"') {
				if(quotedString) {quotedString = false;} 
				else { quotedString = true;}
			}
			if(!quotedString && csv[i] == ' ') {			
				//do nothing
			} else if(!quotedString && csv[i] == '\n') {
				//do nothing
			} else {
				sb.append(csv[i]);
			}
			
		}
		return sb.toString().toCharArray();
	}
	//TODO replace stringbuffer by string builder
	
	/**
	 * 
	 * @param values represent values of a csv line
	 * @return
	 */
	public static String array_to_csv_line(String[] values) {
		StringBuilder stringBuilder = new StringBuilder();
		int last_index = values.length - 1;
		for(int i=0; i < values.length; i++) {
			if (i < last_index) {
				stringBuilder.append(values[i]+',');
			} else {//last value				
				String CR = "\r";
				String LF = "\n";				
				//according csv rfc each line terminates with CR LF
				stringBuilder.append(values[i]+CR+LF); 
			}
		} 
		return stringBuilder.toString();
	}
}
