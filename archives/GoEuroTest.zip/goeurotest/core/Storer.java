package goeurotest.core;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import goeurotest.util.Constants;
import goeurotest.util.Files_io;
/**
 * @Class Storer, store csv in file system.
 * @author Mr. Mounir DJAFER
 * @mailto: mounir.djafer@aol.com
 *
 */
public class Storer {
	
	public static File create_csv_file_to_fill(String directoryPath, String fileName_with_extension) {
		
		return Files_io.createFile_using_File_Path(directoryPath, fileName_with_extension);
	}
	/**
	 * 
	 * @param csv_datas, csv formated datas
	 */
	public static void write_datas_in_csv_file(ArrayList<String[]> csv_datas, 
			File csv_file, boolean append, boolean write_CSV_headers) {
		FileWriter fileWriter = null;
		BufferedWriter bufferedWriter = null;
		try {
			fileWriter = new FileWriter(csv_file, append);
			bufferedWriter = new BufferedWriter(fileWriter);
			if(write_CSV_headers) {
				bufferedWriter.write(Formater.array_to_csv_line(Constants.csv_headers));	
			}
			for (String[] csv_data : csv_datas) { //csv_data represent values of one csv line
				bufferedWriter.write(Formater.array_to_csv_line(csv_data));				
			}
			fileWriter.flush();
			bufferedWriter.flush();
			fileWriter.close();
			bufferedWriter.close();	
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	public static void store_in_csv(ArrayList<String[]> csv_datas, 
			String directoryPath, String CITY_NAME, boolean append,  boolean write_CSV_headers) {
			write_datas_in_csv_file(csv_datas, create_csv_file_to_fill(directoryPath,
					CITY_NAME+Constants.csv_filename_extension), 
					append, write_CSV_headers);
	}
	 
}
